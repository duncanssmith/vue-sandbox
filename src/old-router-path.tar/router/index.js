import Vue from 'vue'
import Router from 'vue-router'
import Store from '@/components/Store'
import Cheese from '@/components/Cheese'
import Fish from '@/components/Fish'
import Veg from '@/components/Veg'
import AddCheese from '@/components/AddCheese'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'store',
      component: Store
    },
    {
      path: '/cheese',
      name: 'cheese',
      component: Cheese
    },
    {
      path: '/fish',
      name: 'fish',
      component: Fish
    },
    {
      path: '/veg',
      name: 'veg',
      component: Veg
    },
    {
      path: '/addCheese',
      name: 'addcheese',
      component: AddCheese
    }
  ]
})
